package bmo.samplewifi;


import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;

import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.Socket;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import okio.ByteString;

/**
 * Handles reading and writing of messages with socket buffers. Uses a Handler
 * to post messages to UI thread for UI updates.
 */
public class ChatManager implements Runnable {

    private Socket socket = null;
    private Handler handler;

    public ChatManager(Socket socket, Handler handler) {
        this.socket = socket;
        this.handler = handler;
    }

    private InputStream iStream;
    private OutputStream oStream;
    private static final String TAG = "ChatHandler";
    private MediaPlayer mediaPlayer;
    private Context context;
    private File mOutputFile;
    static List<byte[]> sList;
    static boolean start = false;


    @Override
    public void run() {
        try {

            iStream = socket.getInputStream();
            oStream = socket.getOutputStream();
            byte[] buffer = new byte[1024];
            int bytes;
            handler.obtainMessage(MainActivity.MY_HANDLE, this)
                    .sendToTarget();

            while (true) {
                try {
                    // Read from the InputStream
                    bytes = iStream.read(buffer);
                    //read(byteeee(iStream).toString());


//                    convertBytesToFile(buffer);
//                    mOutputFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString() + "/Voice Recorder/file.3gp");
//                    mediaPlayer = MediaPlayer.create(context, android.net.Uri.parse(mOutputFile.toURI().toString()));
//                    mediaPlayer.start();

                    if (bytes == -1) {
                        break;
                    }

                    // Send the obtained bytes to the UI Activity
                    Log.d(TAG, "Rec:" + String.valueOf(buffer));

                    //sporocilo:
                    String msg = new String((byte[])buffer, 0, bytes);
                    System.out.println("msg:" + msg);

                    if (msg.equals("start")){
                        System.out.println("START");
                        sList = new ArrayList<>();
                        start = true;
                    }
                    else if (msg.equals("end")) {
                        System.out.println("END");
                        start = false;
                        byte[] data = concatenateByteArrays(sList);
                        System.out.println("SIZE: " + data.length);
                        playReceivedFile(data);
                    }
                    else if(start){
                        //read(msg);
                        sList.add(buffer);
                    }

                    //
                    handler.obtainMessage(MainActivity.MESSAGE_READ,
                            bytes, -1, buffer).sendToTarget();
                } catch (Exception e) {
                    Log.e(TAG, "disconnected", e);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    private void convertBytesToFile(byte[] bytearray) {
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.US);
            File outputFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString()
                    + "/Voice Recorder/file.3gp");
            FileOutputStream fileoutputstream = new FileOutputStream(outputFile);
            fileoutputstream.write(bytearray);
            fileoutputstream.close();

        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    public void write(byte[] buffer) {
        try {
            oStream.write(buffer);
        } catch (IOException e) {
            Log.e(TAG, "Exception during write", e);
        }
    }

    //////////////////
    public void sendAudio(String path) {
        FileChannel in = null;

        try {
            File f = new File(path);
            in = new FileInputStream(f).getChannel();
            sendAudioBytes(in);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void sendAudioBytes(FileChannel in) throws IOException {
        ByteBuffer buff = ByteBuffer.allocateDirect(32);

        while (in.read(buff) > 0) {
            buff.flip();
            byte[] bytes = ByteString.of(buff).toString().getBytes();
            oStream.write(bytes);
            buff.clear();
        }
        socket.setReuseAddress(true);
    }

    private void read(String text) {
//        System.out.println("text: " + text);
//        if (text.equals("start")) {
//            sList.clear();
//        } else if (text.equals("end")) {
//            playReceivedFile();
//        } else {
            try {
                String hexValue = text.substring(text.indexOf("hex=") + 4, text.length() - 1);
                ByteString d = ByteString.decodeHex(hexValue);
                byte[] bytes = d.toByteArray();

                sList.add(bytes);
            } catch (IllegalArgumentException e) {
                e.printStackTrace();
            }
        //}
    }

    public byte[] concatenateByteArrays(List<byte[]> blocks) {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        for (byte[] b : blocks) {
            os.write(b, 0, b.length);
        }
        return os.toByteArray();
    }

    private void read2(String text) {

        try {
            FileOutputStream fos = new FileOutputStream("pathname");
            fos.write(text.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void playReceivedFile(byte[] data) {
        File f = buildAudioFileFromReceivedBytes(data);

        playAudio(f);
    }

    @NonNull
    private File buildAudioFileFromReceivedBytes(byte[] data) {
        System.out.println("FILE...");
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.US);
        File f = new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString()
                + "/Voice Recorder/RECIEVED_"
                + dateFormat.format(new Date())
                + ".3gp");
        try {
            System.out.println("CREATING...");
            f.createNewFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        FileOutputStream out = null;
        try {
            System.out.println("OUtT...");
            out = (new FileOutputStream(f));
        } catch (IOException e) {
            e.printStackTrace();
        }


        try {
            System.out.println("WRITING...");
            System.out.println(data.toString());
            for (byte b : data) {
                out.write(b);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return f;
    }

    private void playAudio(File f) {
        System.out.println("TRYING TO PLAY:::");
        mediaPlayer = new MediaPlayer();
        context = MyApplication.getAppContext();
//        mediaPlayer = MediaPlayer.create(context, android.net.Uri.parse(f.toURI().toString()));
//        mediaPlayer.start();

        try {

            mediaPlayer.setDataSource(context, android.net.Uri.parse(f.getPath()));
            mediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Log.d(TAG, "onClosing: dudation in millis: " + mediaPlayer.getDuration());

        mediaPlayer.start();
    }

    private byte[] byteeee(InputStream is) {
        System.out.println("REEEAAAD");
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();

        int nRead;
        byte[] data = new byte[1024];
        try {
            while ((nRead = is.read(data, 0, data.length)) != -1) {
                buffer.write(data, 0, nRead);
            }


            buffer.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return buffer.toByteArray();
    }

}


