package bmo.samplewifi;


import android.app.Fragment;
import android.content.Context;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;
import android.os.Build;
import android.net.Uri;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileDescriptor;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

/**
 * This fragment handles chat related UI which includes a list view for messages
 * and a message entry field with send button.
 */
public class WiFiChatFragment extends Fragment {

    private View view;
    private ChatManager chatManager;
    private TextView chatLine;
    private ListView listView;
    ChatMessageAdapter adapter = null;
    private List<String> items = new ArrayList<String>();
    private MediaRecorder mRecorder;
    private File mOutputFile;
    private long mStartTime = 0;
    private Handler mHandler = new Handler();
    private MediaPlayer mediaPlayer;
    private Context context;

    public Button button;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_chat, container, false);
        chatLine = (TextView) view.findViewById(R.id.txtChatLine);
        listView = (ListView) view.findViewById(android.R.id.list);
        adapter = new ChatMessageAdapter(getActivity(), android.R.id.text1,
                items);
        listView.setAdapter(adapter);
        view.findViewById(R.id.button1).setOnClickListener(
                new View.OnClickListener() {

                    @Override
                    public void onClick(View arg0) {
                        if (chatManager != null) {
                            chatManager.write(chatLine.getText().toString()
                                    .getBytes());
                            pushMessage("Me: " + chatLine.getText().toString());
                            chatLine.setText("");
                            chatLine.clearFocus();
                        }
                    }
                });
        final TextView textview = (TextView) view.findViewById(R.id.textView);

        button=(Button) view.findViewById(R.id.button2);
        button.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    textview.setText("hopsa");
                    mRecorder = new MediaRecorder();
                    mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                    mRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.HE_AAC);
                        mRecorder.setAudioEncodingBitRate(48000);
                    } else {
                        mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
                        mRecorder.setAudioEncodingBitRate(64000);
                    }
                    mRecorder.setAudioSamplingRate(16000);
                    mOutputFile = getOutputFile();
                    mOutputFile.getParentFile().mkdirs();
                    mRecorder.setOutputFile(mOutputFile.getAbsolutePath());

                    try {
                        mRecorder.prepare();
                        mRecorder.start();
                        mStartTime = SystemClock.elapsedRealtime();
                        Log.d("Voice Recorder","started recording to "+mOutputFile.getAbsolutePath());
                    } catch (IOException e) {
                        Log.e("Voice Recorder", "prepare() failed "+e.getMessage());
                    }
                    return true;
                }
                if(event.getAction() == MotionEvent.ACTION_UP){
                    textview.setText("dsdsd");
                    mRecorder.stop();
                    mRecorder.release();
                    mRecorder = null;
                    mediaPlayer = MediaPlayer.create(context, android.net.Uri.parse(mOutputFile.toURI().toString()));
                    mediaPlayer.start();




                    textview.setText("sent");
                    chatManager.write("start".getBytes());
                    try {
                        System.out.println("WAITING:::");
                        TimeUnit.MILLISECONDS.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    try {
                        //chatManager.sendAudio(mOutputFile.getAbsolutePath());
                        byte[] b = convert(mOutputFile.getAbsolutePath());
                        System.out.println("size: " + b.length);
                        chatManager.write(b);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    try {
                        System.out.println("WAITING:::");
                        TimeUnit.MILLISECONDS.sleep(1000);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    chatManager.write("end".getBytes());
                    //pushFile(mOutputFile);


                    return true;

                }

                return false;
            }
        });
        return view;
    }

    public interface MessageTarget {
        public Handler getHandler();
    }



    private File getOutputFile() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmssSSS", Locale.US);
        return new File(Environment.getExternalStorageDirectory().getAbsolutePath().toString()
                + "/Voice Recorder/RECORDING_"
                + dateFormat.format(new Date())
                + ".3gp");
    }

    public void setChatManager(ChatManager obj) {
        chatManager = obj;
    }

    public void pushMessage(String readMessage) {
        adapter.add(readMessage);
        adapter.notifyDataSetChanged();
    }
//    public void pushFile(File readFile) {
//        try {
//            adapter.add(convert(readFile.getAbsolutePath()));
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        adapter.notifyDataSetChanged();
//    }

    public byte[] convert(String path) throws IOException {

        FileInputStream fis = new FileInputStream(path);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] b = new byte[1024];

        for (int readNum; (readNum = fis.read(b)) != -1;) {
            bos.write(b, 0, readNum);
        }

        byte[] bytes = bos.toByteArray();
        System.out.println("CONVERTED:");
        System.out.println(bytes.toString());
        return bytes;
    }

    /**
     * ArrayAdapter to manage chat messages.
     */
    public class ChatMessageAdapter extends ArrayAdapter<String> {

        List<String> messages = null;

        public ChatMessageAdapter(Context context, int textViewResourceId,
                                  List<String> items) {
            super(context, textViewResourceId, items);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View v = convertView;
            if (v == null) {
                LayoutInflater vi = (LayoutInflater) getActivity()
                        .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
                v = vi.inflate(android.R.layout.simple_list_item_1, null);
            }
            String message = items.get(position);
            if (message != null && !message.isEmpty()) {
                TextView nameText = (TextView) v
                        .findViewById(android.R.id.text1);

                if (nameText != null) {
                    nameText.setText(message);
                    if (message.startsWith("Me: ")) {
                        nameText.setTextAppearance(getActivity(),
                                R.style.normalText);
                    } else {
                        nameText.setTextAppearance(getActivity(),
                                R.style.boldText);
                    }
                }
            }
            return v;
        }
    }
}


